import { Fragment } from '@wordpress/element'

const Hidden = () => <Fragment />

Hidden.config = { design: 'none' }

export default Hidden
