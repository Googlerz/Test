// Importing images
import defaultsidebar from './default.png';
import rightsidebar from './right-sidebar.png';
import leftsidebar from './left-sidebar.png';
import nosidebar from './no-sidebar.png';
import centered from './fullwidth-centered.png';

export { defaultsidebar, rightsidebar, leftsidebar, nosidebar, centered }